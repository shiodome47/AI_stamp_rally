var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var analyze_exports = {};
__export(analyze_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(analyze_exports);
var import_generative_ai = require("@google/generative-ai");
const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { image } = JSON.parse(event.body);
    const apiKey = process.env.VITE_GEMINI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Server configuration error: API Key missing" })
      };
    }
    if (!image) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "No image data provided" })
      };
    }
    const genAI = new import_generative_ai.GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const prompt = "\u3053\u306E\u753B\u50CF\u306F\u3001\u732B\u3001\u307E\u305F\u306F\u5BCC\u58EB\u5C71\u3067\u3059\u304B\uFF1F\u3082\u3057\u305D\u3046\u306A\u3089\u3001\u305D\u306E\u5BFE\u8C61\u7269\u3060\u3051\u3092\u5358\u8A9E\u3067\u4E00\u3064\u7B54\u3048\u3066\u304F\u3060\u3055\u3044\uFF08\u4F8B: 'cat', 'fuji'\uFF09\u3002\u305D\u308C\u4EE5\u5916\u306E\u5834\u5408\u306F'unknown'\u3068\u7B54\u3048\u3066\u304F\u3060\u3055\u3044\u3002\u56DE\u7B54\u306F\u82F1\u8A9E\u306E\u5C0F\u6587\u5B57\u3067\u304A\u9858\u3044\u3057\u307E\u3059\u3002";
    const imagePart = {
      inlineData: {
        data: image,
        mimeType: "image/jpeg"
      }
    };
    const result = await model.generateContent([prompt, imagePart]);
    const response = await result.response;
    const text = response.text().trim().toLowerCase();
    console.log("Gemini Response:", text);
    const tags = [];
    if (text.includes("cat") || text.includes("neko") || text.includes("\u732B")) {
      tags.push("cat");
    }
    if (text.includes("fuji") || text.includes("\u5BCC\u58EB")) {
      tags.push("fuji");
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ tags }),
      headers: {
        "Content-Type": "application/json"
      }
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to analyze image", details: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
